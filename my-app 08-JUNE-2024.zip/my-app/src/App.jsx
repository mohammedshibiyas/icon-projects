import { useState } from 'react'
 import './App.css'
import './Register.css'
import Register from './Register'
import PatientSearch from './Search'


import Demo from './Demo'

import NameSearch from './Search'
import Registercpy from './componenets/Registercpy'

// import PopupRegistrationBox from './PopupRegistrationBox'
// import Selectbox from './Select'
// import SearchComponent from './Select'


function App() {


  return (
    <>
    {/* <Register/> */}
    {/* <Apps/> */}
   {/* <Demo/> */}
   {/* <NameSearch/> */}
    {/* <Select/> */}
  {/* <PatientSearch/> */}
  <Registercpy/>
    
    </>
  )
}

export default App
